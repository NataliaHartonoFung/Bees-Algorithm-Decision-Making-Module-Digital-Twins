function Main()
    clc; clear; close all;

    %% User Input for Algorithm Choice
    disp('Available Algorithms:');
    disp('1. BA');
    disp('2. BA2');
    disp('3. BAF');
    Algorithm_choice = input('Which algorithm do you choose to run? (Enter 1, 2, or 3): ');

    %% Validate Algorithm Choice
    if isempty(Algorithm_choice) || ~ismember(Algorithm_choice, [1, 2, 3])
        error('Invalid algorithm choice. Please select 1, 2, or 3.');
    end

       %% Run the selected algorithm
    switch Algorithm_choice
        case 1
            MainBA;
        case 2
            MainBA2;
        case 3
            MainBAF;
        otherwise
            error('Unexpected error');
    end
end

%% Results are saved to mat file [AlgorithmnName]_[distance].mat